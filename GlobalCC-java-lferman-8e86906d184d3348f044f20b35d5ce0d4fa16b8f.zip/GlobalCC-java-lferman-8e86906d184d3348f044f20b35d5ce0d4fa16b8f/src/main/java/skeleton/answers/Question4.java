package skeleton.answers;

public class Question4 {

    public static int choosingWisely(int[] v, int[] c, int mc) {
        // TODO Auto-generated method stub
        return -5;
    }
}
