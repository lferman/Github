public class TestCase {

    private int testNumber;
    private String input;
    private int output;

    TestCase() {
    }

    int getTestNumber() {
        return testNumber;
    }

    void setTestNumber(int testNumber) {
        this.testNumber = testNumber;
    }

    String getInput() {
        return input;
    }

    void setInput(String input) {
        this.input = input;
    }

    int getOutput() {
        return output;
    }

    void setOutput(int output) {
        this.output = output;
    }
}
